gw_nsprcomp.cv <-
  function (bw,
            x,
            loc,
            k,
            kernel = "bisquare",
            adaptive = FALSE,
            p = 2,
            theta = 0,
            longlat = F,
            dMat,
            nneg = TRUE,
            center = TRUE)
  {
    ##This function is based on GWmodel::gwpca.cv and nsprcomp::nsprcomp

    requireNamespace("GWmodel")
    requireNamespace("nsprcomp")

    w_nsprcomp <- function(x = x, wt = wt, ncomp = ncomp, k = ncol(x), nneg = nneg,  center = center,...) {
      wt_x <- x * wt
      nsprcomp(wt_x, ncomp = ncomp, k = ncol(x), nneg = nneg, center = center, ...)
    }

    if (missing(dMat))
      DM.given <- F
    else
      DM.given <- T
    n <- nrow(loc)
    score <- 0
    for (i in 1:n) {
      if (DM.given)
        dist.vi <- dMat[, i]
      else {
        dist.vi <- gw.dist(
          loc,
          focus = i,
          p = p,
          theta = theta,
          longlat = longlat
        )
      }
      wt <- gw.weight(dist.vi, bw, kernel, adaptive)
      wt[i] <- 0
      use <- wt > 0
      wt <- wt[use]
      if (length(wt) <= 1) {
        score <- Inf
        expr <- paste("Too small bandwidth: ", bw)
        warning(paste(expr, "and the CV value can't be given there.",
                      sep = ", "))
        break
      }

      ncomp <- k

      temp <- w_nsprcomp(x = x[use,],
                         wt,
                         ncomp = ncomp,
                         k = ncol(x),
                         nneg = nneg,
                         center = center)
      v <- temp$rotation %*% t(temp$rotation)
      score <- score + sum((x[i,] - x[i,] %*% v)) ^ 2
    }
    if (adaptive)
      cat("Adaptive bandwidth(number of nearest neighbours):",
          bw,
          "CV score:",
          score,
          "\n")
    else
      cat("Fixed bandwidth:", bw, "CV score:", score, "\n")
    score
  }
